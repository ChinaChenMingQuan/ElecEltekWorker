await navigator.serviceWorker.register("service-worker.js");
await Blazor.start();
export {};
//# sourceMappingURL=main.js.map